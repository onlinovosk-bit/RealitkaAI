'use client'

// ================================================================
// Revolis.AI — /team/permissions
// Route group: /(dashboard)/team/permissions/page.tsx
//
// ZERO external dependencies — používa len:
//   - React (built-in)
//   - Next.js Link
//   - Inline styles (žiadne @/components importy)
// ================================================================

import Link from 'next/link'

/* ── Role definitions ────────────────────────────────────────── */
const ROLES = [
  {
    id:    'owner',
    label: 'Owner',
    color: '#1B3A5C',
    bg:    '#EFF6FF',
    desc:  'Plný prístup — fakturácia, tím, nastavenia, všetky dáta',
    perms: [
      'Zobraziť všetky príležitosti',
      'Upraviť a zmazať príležitosti',
      'Spravovať tím a oprávnenia',
      'Prístup k fakturácii a plánu',
      'Export kontaktov (neobmedzený)',
      'Integrácie a API kľúče',
      'Integrity Monitor — všetky alerty',
      'Protocol Authority funkcie',
    ],
    denied: [] as string[],
  },
  {
    id:    'senior',
    label: 'Senior maklér',
    color: '#2563EB',
    bg:    '#EFF6FF',
    desc:  'Rozšírený prístup — vlastné leady + tímové štatistiky',
    perms: [
      'Zobraziť vlastné príležitosti',
      'Zobraziť tímové štatistiky (len čítanie)',
      'Export vlastných kontaktov (max 100/deň)',
      'BRI Live Score — vlastné leady',
      'Morning Brief',
      'Arbitráž Engine (len návrhy)',
    ],
    denied: [
      'Fakturácia a plán',
      'Integrity Monitor',
      'Tímové oprávnenia',
    ],
  },
  {
    id:    'agent',
    label: 'Maklér',
    color: '#0EA5E9',
    bg:    '#F0F9FF',
    desc:  'Základný prístup — vlastné leady a aktivity',
    perms: [
      'Zobraziť vlastné príležitosti',
      'BRI Live Score — vlastné leady',
      'Morning Brief',
      'Export vlastných kontaktov (max 30/deň)',
    ],
    denied: [
      'Tímové štatistiky',
      'Arbitráž Engine',
      'Fakturácia a plán',
      'Integrity Monitor',
      'API kľúče',
    ],
  },
]

/* ── Team members ────────────────────────────────────────────── */
const TEAM_MEMBERS = [
  { name: 'Reality Smolko', initials: 'RS', email: 'smolko@realita.sk',  role: 'owner',  active: true  },
  { name: 'Andrej Novák',   initials: 'AN', email: 'novak@realita.sk',   role: 'senior', active: true  },
  { name: 'Jana Horáková',  initials: 'JH', email: 'horakova@realita.sk',role: 'agent',  active: true  },
  { name: 'Peter Kováč',    initials: 'PK', email: 'kovac@realita.sk',   role: 'agent',  active: false },
]

/* ── Check icon ──────────────────────────────────────────────── */
function CheckIcon({ color }: { color: string }) {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="6" cy="6" r="6" fill={color} fillOpacity=".15" />
      <path d="M3.5 6L5.2 7.7L8.5 4.3" stroke={color} strokeWidth="1.2"
            strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function CrossIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0 }}>
      <circle cx="6" cy="6" r="6" fill="#E2E8F0" />
      <path d="M4 4L8 8M8 4L4 8" stroke="#94A3B8" strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  )
}

/* ── Page ────────────────────────────────────────────────────── */
export default function TeamPermissionsPage() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

      {/* Back link */}
      <div>
        <Link
          href="/team"
          style={{
            fontSize: 12, color: '#7A8BA8', textDecoration: 'none',
            display: 'inline-flex', alignItems: 'center', gap: 4,
          }}
        >
          ← Späť na tím
        </Link>
      </div>

      {/* Page header */}
      <div>
        <h1 style={{ fontSize: 22, fontWeight: 700, color: '#0C1B2D', marginBottom: 4 }}>
          Oprávnenia tímu
        </h1>
        <p style={{ fontSize: 13, color: '#7A8BA8' }}>
          Správa prístupov a rolí maklérov
        </p>
      </div>

      {/* Role cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 12 }}>
        {ROLES.map(role => (
          <div
            key={role.id}
            style={{
              background: '#fff',
              border: `1px solid ${role.color}30`,
              borderRadius: 10,
              padding: '16px 18px',
            }}
          >
            {/* Role badge */}
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '3px 10px', borderRadius: 20,
              background: role.bg,
              border: `0.5px solid ${role.color}40`,
              marginBottom: 10,
            }}>
              <div style={{
                width: 6, height: 6, borderRadius: '50%', background: role.color,
              }} />
              <span style={{ fontSize: 11, fontWeight: 700, color: role.color }}>
                {role.label}
              </span>
            </div>

            <p style={{ fontSize: 11, color: '#7A8BA8', marginBottom: 12, lineHeight: 1.5 }}>
              {role.desc}
            </p>

            <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
              {role.perms.map(p => (
                <div key={p} style={{ display: 'flex', alignItems: 'center', gap: 7,
                                      fontSize: 11, color: '#0C1B2D' }}>
                  <CheckIcon color={role.color} />
                  {p}
                </div>
              ))}
              {role.denied.map(p => (
                <div key={p} style={{ display: 'flex', alignItems: 'center', gap: 7,
                                      fontSize: 11, color: '#94A3B8' }}>
                  <CrossIcon />
                  {p}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      {/* Team members table */}
      <div style={{
        background: '#fff', border: '1px solid #D6E2EF',
        borderRadius: 10, padding: '16px 18px',
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between',
                      alignItems: 'center', marginBottom: 14 }}>
          <div>
            <h2 style={{ fontSize: 14, fontWeight: 700, color: '#0C1B2D', marginBottom: 2 }}>
              Členovia tímu
            </h2>
            <p style={{ fontSize: 11, color: '#7A8BA8' }}>
              {TEAM_MEMBERS.length} členov · {TEAM_MEMBERS.filter(m => m.active).length} aktívnych
            </p>
          </div>
          <button style={{
            padding: '6px 14px', background: '#1B3A5C', border: 'none',
            borderRadius: 8, fontSize: 11, fontWeight: 600, color: '#fff', cursor: 'pointer',
          }}>
            + Pozvať makléra
          </button>
        </div>

        {/* Header */}
        <div style={{
          display: 'grid', gridTemplateColumns: '1fr 200px 130px 90px',
          gap: 12, padding: '6px 12px',
          fontSize: 9, fontWeight: 700, letterSpacing: '0.12em',
          color: '#7A8BA8', textTransform: 'uppercase',
          borderBottom: '1px solid #D6E2EF', marginBottom: 4,
        }}>
          <span>Maklér</span>
          <span>E-mail</span>
          <span>Rola</span>
          <span>Stav</span>
        </div>

        {/* Rows */}
        {TEAM_MEMBERS.map((m, i) => {
          const role = ROLES.find(r => r.id === m.role)!
          return (
            <div
              key={m.email}
              style={{
                display: 'grid', gridTemplateColumns: '1fr 200px 130px 90px',
                gap: 12, padding: '10px 12px', alignItems: 'center',
                borderBottom: i < TEAM_MEMBERS.length - 1
                  ? '1px solid #D6E2EF' : 'none',
              }}
            >
              {/* Name + avatar */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{
                  width: 30, height: 30, borderRadius: '50%',
                  background: role.bg,
                  border: `1px solid ${role.color}30`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 10, fontWeight: 800, color: role.color, flexShrink: 0,
                }}>
                  {m.initials}
                </div>
                <span style={{ fontSize: 13, fontWeight: 600, color: '#0C1B2D' }}>
                  {m.name}
                </span>
              </div>

              {/* Email */}
              <span style={{ fontSize: 11, color: '#7A8BA8', fontFamily: 'monospace' }}>
                {m.email}
              </span>

              {/* Role badge */}
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 5,
                padding: '3px 9px', borderRadius: 20, width: 'fit-content',
                background: role.bg, border: `0.5px solid ${role.color}30`,
              }}>
                <div style={{
                  width: 5, height: 5, borderRadius: '50%', background: role.color,
                }} />
                <span style={{ fontSize: 10, fontWeight: 700, color: role.color }}>
                  {role.label}
                </span>
              </div>

              {/* Status */}
              <div style={{
                display: 'inline-flex', alignItems: 'center', gap: 5,
                padding: '3px 9px', borderRadius: 20, width: 'fit-content',
                background: m.active ? '#F0FDF4' : '#F8FAFC',
                border: `0.5px solid ${m.active ? '#BBF7D0' : '#D6E2EF'}`,
              }}>
                <div style={{
                  width: 5, height: 5, borderRadius: '50%',
                  background: m.active ? '#059669' : '#CBD5E1',
                }} />
                <span style={{
                  fontSize: 10, fontWeight: 700,
                  color: m.active ? '#059669' : '#94A3B8',
                }}>
                  {m.active ? 'Aktívny' : 'Neaktívny'}
                </span>
              </div>
            </div>
          )
        })}
      </div>

      {/* Integrity Monitor warning */}
      <div style={{
        background: '#FFFBEB', border: '1px solid #FDE68A',
        borderRadius: 10, padding: '14px 16px',
        display: 'flex', gap: 12, alignItems: 'flex-start',
      }}>
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"
             style={{ flexShrink: 0, marginTop: 1 }}>
          <path d="M8 2L14 13H2L8 2Z" fill="#D97706" fillOpacity=".2"
                stroke="#D97706" strokeWidth="1" strokeLinejoin="round" />
          <path d="M8 6V9M8 11V11.5" stroke="#D97706" strokeWidth="1.2"
                strokeLinecap="round" />
        </svg>
        <div>
          <p style={{ fontSize: 12, fontWeight: 700, color: '#D97706', marginBottom: 3 }}>
            Agent Integrity Monitor je aktívny
          </p>
          <p style={{ fontSize: 11, color: '#78350F', lineHeight: 1.5 }}>
            Každý export kontaktov je logovaný. Pri prekročení limitu (50 exportov/deň)
            dostanete e-mail alert okamžite. Databáza kontaktov je vaše najcennejšie
            aktívum — chránime ho automaticky.
          </p>
        </div>
      </div>

    </div>
  )
}
